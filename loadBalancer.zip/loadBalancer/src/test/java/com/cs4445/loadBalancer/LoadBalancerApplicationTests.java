package com.cs4445.loadBalancer;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LoadBalancerApplicationTests {

	@Test
	void contextLoads() {
	}

}
